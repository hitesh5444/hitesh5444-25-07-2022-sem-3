// Local

document.write(+Number("3.465464"))
document.write("<br>"+Number(" "))
document.write("<br>"+Number(""))
document.write("<br>"+Number("100 + 54"))

// Globle

let num = 54;

let s = String (35534);

document.write("<br>"+String(100 + 58))
document.write("<br>"+Number(+num+100+50))
document.write("<br>"+String(s+100))

let kk = 3.14;

document.write("<br>"+kk.toString())
document.write("<br>"+String(kk+kk.toString()))


let numexp = 3.56;

document.write("<br>"+numexp.toExponential(1));
document.write("<br>"+numexp.toExponential(2));
document.write("<br>"+numexp.toExponential(3));
document.write("<br>"+numexp.toExponential(4));

let numfix = 5.146;

document.write("<br>"+numfix.toFixed());
document.write("<br>"+numfix.toFixed(2));
document.write("<br>"+numfix.toFixed(4));
document.write("<br>"+numfix.toFixed(6));

let numprec = 46.151;266

document.write("<br/>"+numprec.toPrecision());
document.write("<br/>"+numprec.toPrecision(2));
document.write("<br/>"+numprec.toPrecision(4));
document.write("<br/>"+numprec.toPrecision(6));

 
 document.write("<br>"+Number(true));
 document.write("<br>"+Number(false));
document.write("<br>"+Number("11"));
document.write("<br>"+Number(" 11"));
document.write("<br>"+Number("11.33"));
document.write("<br>"+Number("11 33"));
document.write("<br>"+Number("11:33 "));
document.write("<br>"+Number("11 "));
document.write("<br>"+Number("ABC"));
document.write("<br>"+Number(new Date("2004-04-11")));


document.write("<br>"+Number.parseInt(10.33));
document.write("<br>"+Number.parseInt(-10.33));
document.write("<br>"+Number.parseInt(10));
document.write("<br>"+Number.parseInt(-10));
document.write("<br>"+Number.parseInt("abc"));

document.write("<br>"+Number.parseFloat(-50.55));
document.write("<br>"+Number.parseFloat(-50));
document.write("<br>"+Number.parseFloat(-50.55));
document.write("<br>"+Number.parseFloat(50.55));
document.write("<br>"+Number.parseFloat(50));


Array.prototype.upperCase = function() {
    var i;
    for (i = 0; i < this.length; i++) {
        this[i] = this[i].toUpperCase();
    }
};
 
function demoArr() {
    var cars = ["bmw", "ferrari"];
    document.write("<br/>"+cars); 
    cars.upperCase();
    document.write("<br/>"+cars); 
    document.write("<br/>"+cars); 
    document.write("<br/>"+cars); 

    var bikes = ["bullet", "kawasaki"];
    document.write("<br/>"+bikes); 
    bikes.upperCase();
    document.write("<br/>"+bikes); 
}


var d = new Date();
document.write("<br/>"+d.toString());
document.write("<br/>"+d.toUTCString());
document.write("<br/>"+d.toDateString());
document.write("<br/>"+d.toISOString());

document.write("<br/>"+d.getTime()); 
document.write("<br/>"+d.getDate()); 
document.write("<br/>"+d.getDay()); 
document.write("<br/>"+d.getFullYear()); 
document.write("<br/>"+d.getHours()); 
document.write("<br/>"+d.getMonth()); 

document.write("<br/>"+d.getDay()+"/"+d.getMonth()+"/"+d.getFullYear());